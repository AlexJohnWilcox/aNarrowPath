package edu.highpoint.tester;

import androidx.annotation.NonNull;

public class CharacterAttributes {
    private static final CharacterAttributes instance = new CharacterAttributes();

    public int strength = 2; // Damage
    public int healthMax = 20; // Health
    public int healthCurrent = 20; // Current Health
    public int dexterity = 1; // Not Set (block chance?)
    public int stamina = 10; // Percent Chance to escape
    public int luck = 1; // Not set (increase gold drop)
    public int charisma = 1; // Not set (More shop options?)
    public int gold = 10; // Shop currency
    public int sword = 0; // Sword status (None, Wooden, Bronze, Steel, Magic)
    public int heal = 1; // Heal items

    // Private constructor to prevent instantiation
    private CharacterAttributes() {}

    // Get the singleton instance
    public static CharacterAttributes getInstance() {
        return instance;
    }

    // Getter and Setter for Strength
    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    // Getter and Setter for Health
    public int getHealth() {
        return healthMax;
    }

    public void setHealth(int healthMax) {
        this.healthMax = healthMax;
    }

    // Getter and Setter for Current Health
    public int getHealthCurrent() {
        return healthCurrent;
    }

    public void setHealthCurrent(int healthCurrent) {
        this.healthCurrent = healthCurrent;
    }

    // Getter and Setter for Dexterity
    public int getDexterity() {
        return dexterity;
    }

    public void setDexterity(int dexterity) {
        this.dexterity = dexterity;
    }

    // Getter and Setter for Stamina
    public int getStamina() {
        return stamina;
    }

    public void setStamina(int stamina) {
        this.stamina = stamina;
    }

    // Getter and Setter for Luck
    public int getLuck() {
        return luck;
    }

    public void setLuck(int luck) {
        this.luck = luck;
    }

    // Getter and Setter for Charisma
    public int getCharisma() {
        return charisma;
    }

    public void setCharisma(int charisma) {
        this.charisma = charisma;
    }

    public int getGold() { return gold; }

    public void setGold(int gold) { this.gold = gold; }

    public int getSword() { return sword; }

    public void setSword(int sword) { this.sword = sword; }

    public int getHeal() { return heal; }

    public void setHeal(int heal) { this.heal = heal; }
}
