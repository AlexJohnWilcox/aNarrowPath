package edu.highpoint.tester;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Shop extends AppCompatActivity {

    TextView goldTextView, statusMessageTextView;
    Button buyHealthPotionButton, buySwordButton, exitShopButton,buttonFightShopKeep;

    // Player attributes (replace with your character attributes if needed)
    CharacterAttributes attributes = CharacterAttributes.getInstance();
    public int playerGold;
    public int heal;
    public int sword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop);

        // Initialize views
        goldTextView = findViewById(R.id.goldTextView);
        statusMessageTextView = findViewById(R.id.statusMessageTextView);
        buyHealthPotionButton = findViewById(R.id.buyHealthPotionButton);
        buySwordButton = findViewById(R.id.buySwordButton);
        exitShopButton = findViewById(R.id.exitShopButton);
        buttonFightShopKeep = findViewById(R.id.buttonFightShopKeep);

        // Get current player attributes
        playerGold = attributes.getGold();  // Assume player starts with some gold
        heal = attributes.getHeal();        // Health potions the player has
        sword = attributes.getSword();      // Sword level the player has

        // Update the gold display
        updateGoldDisplay();

        // Buy health potion action
        buyHealthPotionButton.setOnClickListener(v -> buyHealthPotion());

        // Buy sword action
        buySwordButton.setOnClickListener(v -> buySword());

        // Exit shop action
        exitShopButton.setOnClickListener(v -> exitShop());

        buttonFightShopKeep.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), FightShop.class);
            startActivity(intent);});
    }

    public void updateGoldDisplay() {
        goldTextView.setText("Gold: " + playerGold);
    }

    public void buyHealthPotion() {
        int potionCost = 10;
        if (playerGold >= potionCost) {
            playerGold -= potionCost;
            heal += 1;
            attributes.setGold(playerGold);  // Update player's gold in attributes
            attributes.setHeal(heal);        // Update player's heal count
            statusMessageTextView.setText("You bought a Health Potion!");
            updateGoldDisplay();
        } else {
            statusMessageTextView.setText("Not enough gold to buy a Health Potion.");
        }
    }

    public void buySword() {
        int swordCost = 50;
        if (playerGold >= swordCost) {
            playerGold -= swordCost;
            sword += 1;
            attributes.setGold(playerGold);  // Update player's gold in attributes
            attributes.setSword(sword);      // Update player's sword level
            statusMessageTextView.setText("You bought a new Sword!");
            updateGoldDisplay();
        } else {
            statusMessageTextView.setText("Not enough gold to buy a Sword.");
        }
    }

    public void exitShop() {
        // Navigate back to the Game (Trail) activity
        Intent intent = new Intent(getApplicationContext(), Game.class);
        startActivity(intent);
        finish(); // Close the shop activity
    }
}

