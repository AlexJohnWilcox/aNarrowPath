package edu.highpoint.tester;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FightShop extends AppCompatActivity {

    public TextView enemyEncounterTextView, enemyHealthTextView, playerHealthTextView;
    public ProgressBar enemyHealthBar, playerHealthBar;
    public Button fightButton, runButton;
    public List<Object[]> enemyList;  // List of enemies where each entry contains [name, health, minDamage, maxDamage]
    public String currentEnemyName;
    public int currentEnemyHealth, currentEnemyMinDamage, currentEnemyMaxDamage, minGoldDrop, maxGoldDrop;
    public Random random;
    CharacterAttributes attributes = CharacterAttributes.getInstance();
    //int currentHealth = attributes.getHealth();
    public TextView textViewDamageInfo, textViewRunAwayInfo;
    public Button buttonContinueFight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_fight);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize UI components
        enemyEncounterTextView = findViewById(R.id.enemyEncounterTextView);
        enemyHealthTextView = findViewById(R.id.enemyHealthTextView);
        playerHealthTextView = findViewById(R.id.playerHealthTextView);
        enemyHealthBar = findViewById(R.id.enemyHealthBar);
        playerHealthBar = findViewById(R.id.playerHealthBar);
        fightButton = findViewById(R.id.fightButton);
        runButton = findViewById(R.id.runButton);
        textViewRunAwayInfo = findViewById(R.id.textViewRunAwayInfo);
        textViewDamageInfo = findViewById(R.id.textViewDamageInfo);
        buttonContinueFight = findViewById(R.id.buttonContinueFight);

        random = new Random();

        CharacterAttributes attributes = CharacterAttributes.getInstance();
        int currentStrength = attributes.getStrength();
        int currentSword = attributes.getSword();                           // Get strength and sword attributes
        int baseDamage = currentStrength;
        if (currentSword == 1) // Check for wooden sword
            baseDamage = baseDamage + 2; // Add 2 damage if wooden sword is held
        textViewDamageInfo.setText("Deals " + (baseDamage - 2) + "-" + (baseDamage + 2) + " damage");

        int currentStamina = attributes.getStamina(); // Get stamina attribute

        textViewRunAwayInfo.setText(currentStamina + "% chance to escape");

        // Initialize the enemy list and encounter an enemy
        setupEnemyList();
        encounterEnemy();

        // Set up fight and run actions
        fightButton.setOnClickListener(v -> fightEnemy());
        //runButton.setOnClickListener(v -> runAway());
        buttonContinueFight.setOnClickListener(v -> continueToTrail());
    }

    // Initialize the list of potential enemies with health and damage range values
    public void setupEnemyList() {
        enemyList = new ArrayList<>();

        // Add enemies with name, health, minDamage, maxDamage values, min Gold, max Gold
        enemyList.add(new Object[]{"Shop Keeper", 100, 5, 15, 250, 500});
    }

    // Function to encounter a random enemy
    public void encounterEnemy() {

        int currentPlayerHealth = attributes.getHealthCurrent(); // Get current health of the player
        int maxPlayerHealth = attributes.getHealth(); // Get max health of the player

        // Randomly select an enemy
        Object[] selectedEnemy = enemyList.get(random.nextInt(enemyList.size()));
        currentEnemyName = (String) selectedEnemy[0];
        currentEnemyHealth = (int) selectedEnemy[1];
        currentEnemyMinDamage = (int) selectedEnemy[2];
        currentEnemyMaxDamage = (int) selectedEnemy[3];
        minGoldDrop = (int) selectedEnemy[4];
        maxGoldDrop = (int) selectedEnemy[5];

        // Update UI for the enemy
        enemyHealthTextView.setText(currentEnemyName + " Health: " + currentEnemyHealth);

        // Set enemy health bar values
        enemyHealthBar.setMax(currentEnemyHealth);
        enemyHealthBar.setProgress(currentEnemyHealth);

        // Update UI for the player
        playerHealthTextView.setText("Your Health: " + currentPlayerHealth + "/" + maxPlayerHealth);

        // Set player health bar values
        playerHealthBar.setMax(maxPlayerHealth); // Set the health bar's max to the player's max health
        playerHealthBar.setProgress(currentPlayerHealth); // Set the health bar's current progress to the player's current health
    }

    // Action when the player chooses to fight
    public void fightEnemy() {
        CharacterAttributes attributes = CharacterAttributes.getInstance();
        int currentPlayerHealth = attributes.getHealthCurrent(); // Current player health
        int maxPlayerHealth = attributes.getHealth(); // Max player health

        int currentStrength = attributes.getStrength();
        int currentSword = attributes.getSword();  // Get strength and sword attributes
        int baseDamage = currentStrength;

        if (currentSword == 1) // Check for wooden sword
            baseDamage = baseDamage + 2; // Add 2 damage if wooden sword is held

        Random random = new Random();
        int playerDamage = baseDamage + random.nextInt(5) - 2; // Player deals damage based on stats

        int enemyDamage = random.nextInt(currentEnemyMaxDamage - currentEnemyMinDamage + 1) + currentEnemyMinDamage;  // Enemy deals damage within its range

        // Decrease enemy health
        currentEnemyHealth -= playerDamage;

        if (currentEnemyHealth <= 0) {
            currentEnemyHealth = 0;
            int enemyGoldDrop = random.nextInt(maxGoldDrop - minGoldDrop + 1) + minGoldDrop;
            enemyEncounterTextView.setText("You defeated " + currentEnemyName + " and gained " + enemyGoldDrop + " gold!");

            int currentGold = attributes.getGold() + enemyGoldDrop;
            attributes.setGold(currentGold);

            fightButton.setEnabled(false);  // Disable fight button after victory
            runButton.setEnabled(false); // Disable run button after victory
            buttonContinueFight.setVisibility(View.VISIBLE);
        } else {
            // Enemy counterattacks
            currentPlayerHealth -= enemyDamage;

            if (currentPlayerHealth <= 0) {
                currentPlayerHealth = 0;
                attributes.setHealthCurrent(currentPlayerHealth); // Update current player health to 0 in attributes
                enemyEncounterTextView.setText("The " + currentEnemyName + " defeated you!");
                fightButton.setEnabled(false);  // Disable fight button after defeat
                runButton.setEnabled(false);    // Disable run button after defeat
            } else {
                enemyEncounterTextView.setText("You hit the " + currentEnemyName + " for " + playerDamage + " damage. The " + currentEnemyName + " swings and deals " + enemyDamage + " damage.");
                attributes.setHealthCurrent(currentPlayerHealth); // Update current player health in attributes
            }
        }

        // Update UI for enemy health
        enemyHealthTextView.setText(currentEnemyName + " Health: " + currentEnemyHealth);
        enemyHealthBar.setProgress(currentEnemyHealth);

        // Update UI for player health
        playerHealthTextView.setText("Your Health: " + currentPlayerHealth + "/" + maxPlayerHealth);
        playerHealthBar.setMax(maxPlayerHealth); // Ensure the max of the health bar is set to the max health
        playerHealthBar.setProgress(currentPlayerHealth); // Update the player's health bar with the current health
    }

    public void continueToTrail() {
        Intent intent = new Intent(getApplicationContext(), Game.class);
        startActivity(intent);
    }
}