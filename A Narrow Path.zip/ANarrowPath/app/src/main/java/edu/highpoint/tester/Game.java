package edu.highpoint.tester;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class Game extends AppCompatActivity {

    // UI Elements
    TextView textViewDirectionResult;
    TextView textViewStory;
    Button buttonNorth;
    Button buttonSouth;
    Button buttonEast;
    Button buttonWest;
    TextView attributesTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);  // Ensure this is pointing to the correct XML file

        // Set window insets to adjust for system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.gameLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Enable dark mode
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

        // Initialize views
        initializeViews();

        // Display the character attributes when the game starts
        displayAttributes();
    }

    // Function to initialize all views
    public void initializeViews() {
        textViewDirectionResult = findViewById(R.id.textViewDirectionResult);
        textViewStory = findViewById(R.id.textViewStory);
        buttonNorth = findViewById(R.id.buttonNorth);
        buttonSouth = findViewById(R.id.buttonSouth);
        buttonEast = findViewById(R.id.buttonEast);
        buttonWest = findViewById(R.id.buttonWest);
        attributesTextView = findViewById(R.id.attributesTextView);

        // Set onClick listeners for direction buttons
        buttonNorth.setOnClickListener(this::handleDirection);
        buttonSouth.setOnClickListener(this::handleDirection);
        buttonEast.setOnClickListener(this::handleDirection);
        buttonWest.setOnClickListener(this::handleDirection);
    }

    // Display character attributes in the stats section
    public void displayAttributes() {
        CharacterAttributes attributes = CharacterAttributes.getInstance();

        // Build the string for displaying character attributes
        StringBuilder statsBuilder = new StringBuilder();
        statsBuilder.append("Strength: ").append(attributes.getStrength()).append("\n");
        statsBuilder.append("Health: ").append(attributes.getHealthCurrent()).append("/").append(attributes.getHealth()).append("\n");
        statsBuilder.append("Dexterity: ").append(attributes.getDexterity()).append("\n");
        statsBuilder.append("Stamina: ").append(attributes.getStamina()).append("\n");
        statsBuilder.append("Luck: ").append(attributes.getLuck()).append("\n");
        statsBuilder.append("Charisma: ").append(attributes.getCharisma()).append("\n");
        statsBuilder.append("Gold: ").append(attributes.getGold()).append("\n");
        statsBuilder.append("Sword Level: ").append(attributes.getSword()).append("\n");
        statsBuilder.append("Heals Available: ").append(attributes.getHeal()).append("\n");

        // Set the attributes text to display the stats
        attributesTextView.setText(statsBuilder.toString());
    }

    // Handle button clicks for directions
    public void handleDirection(View view) {
        String direction = "";
        int id = view.getId();

        // Determine the direction based on the button clicked
        if (id == R.id.buttonNorth) {
            direction = "North";
        } else if (id == R.id.buttonSouth) {
            direction = "South";
        } else if (id == R.id.buttonEast) {
            direction = "East";
        } else if (id == R.id.buttonWest) {
            direction = "West";
        }

        // Random number generation (1 in 4 chance)
        Random rand = new Random();
        int randomNumber = rand.nextInt(4); // Generates a random number between 0 and 3

        // Perform different actions based on the random number
        if (randomNumber == 0) {
            String directionText = "You head " + direction + "... nothing but trees all around, and the moon shining overhead.";
            textViewDirectionResult.setText(directionText);
        } else if (randomNumber == 1) {
            // Move to the Fight screen
            Intent intent = new Intent(getApplicationContext(), Fight.class);
            startActivity(intent);
        } else if (randomNumber == 2) {
            // Move to the Shop screen
            Intent intent = new Intent(getApplicationContext(), Shop.class);
            startActivity(intent);
        } else {
            optionFour(); // Handle other outcomes
        }
    }

    // Option four logic (to be defined)
    public void optionFour() {
        // Option four logic (e.g., some special event)
        String eventText = "You found some gold on the floor...";
        textViewDirectionResult.setText(eventText);
        CharacterAttributes attributes = CharacterAttributes.getInstance();
        int gold = attributes.getGold();
        attributes.setGold(gold + 10);
    }
}
