package edu.highpoint.tester;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView textViewPrologText;
    TextView textViewPrologText2;
    TextView textViewProlog3;
    TextView textViewNameText;
    EditText editTextNameInput;
    Button buttonChoiceStrength;
    Button buttonChoiceHealth;
    Button buttonChoiceDexterity;
    Button buttonStamina;
    Button buttonLuck;
    Button buttonCharisma;
    Button buttonGold;
    Button buttonSword;
    Button buttonHeal;
    Button buttonContinue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Set window insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

        // Initialize views
        textViewPrologText = findViewById(R.id.textViewPrologText);
        textViewPrologText2 = findViewById(R.id.textViewPrologText2);
        textViewProlog3 = findViewById(R.id.textViewProlog3);
        buttonChoiceStrength = findViewById(R.id.buttonChoiceStrength);
        buttonChoiceHealth = findViewById(R.id.buttonChoiceHealth);
        buttonChoiceDexterity = findViewById(R.id.buttonChoiceDexterity);
        buttonStamina = findViewById(R.id.buttonStamina);
        buttonLuck = findViewById(R.id.buttonLuck);
        buttonCharisma = findViewById(R.id.buttonCharisma);
        buttonGold = findViewById(R.id.buttonGold);
        buttonSword = findViewById(R.id.buttonSword);
        buttonHeal = findViewById(R.id.buttonHeal);
        buttonContinue = findViewById(R.id.buttonContinue);
        textViewNameText = findViewById(R.id.textViewNameText);
        editTextNameInput = findViewById(R.id.editTextNameInput);

        // Hide the Continue button initially
        buttonContinue.setVisibility(View.GONE);

        // Set listener for when the user presses "Enter" on the keyboard
        editTextNameInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {

                String enteredName = editTextNameInput.getText().toString();
                if (enteredName == "admin") {
                    CharacterAttributes attributes = CharacterAttributes.getInstance();
                    attributes.setHealth(1000);
                    attributes.setGold(1000);
                    attributes.setStrength(100);
                }

                if (!enteredName.isEmpty()) {
                    // Make the Continue button visible
                    buttonContinue.setVisibility(View.VISIBLE);
                    // Disable the EditText to prevent further name entry
                    editTextNameInput.setEnabled(false);
                    // Optionally, update the UI to show the entered name
                    textViewNameText.setText("");
                }
                return true;
            }
            return false;
        });

        // Set onClickListeners for buttons
        buttonChoiceStrength.setOnClickListener(v -> {
            strengthFunction();
            disableOtherButtons1(buttonChoiceStrength);
        });

        buttonChoiceHealth.setOnClickListener(v -> {
            healthFunction();
            disableOtherButtons1(buttonChoiceHealth);
        });

        buttonChoiceDexterity.setOnClickListener(v -> {
            dexterityFunction();
            disableOtherButtons1(buttonChoiceDexterity);
        });

        buttonStamina.setOnClickListener(v -> {
            staminaFunction();
            disableOtherButtons2(buttonStamina);
        });

        buttonLuck.setOnClickListener(v -> {
            luckFunction();
            disableOtherButtons2(buttonLuck);
        });

        buttonCharisma.setOnClickListener(v -> {
            charismaFunction();
            disableOtherButtons2(buttonCharisma);
        });

        buttonGold.setOnClickListener(v -> {
            goldFunction();
            disableOtherButtons3(buttonGold);
        });

        buttonSword.setOnClickListener(v -> {
            swordFunction();
            disableOtherButtons3(buttonSword);
        });

        buttonHeal.setOnClickListener(v -> {
            healFunction();
            disableOtherButtons3(buttonHeal);
        });

        buttonContinue.setOnClickListener(v -> {
            continueFunction();
        });
    }

    public void strengthFunction() {
        // Increment strength
        CharacterAttributes attributes = CharacterAttributes.getInstance();
        int currentStrength = attributes.getStrength() + 2;
        attributes.setStrength(currentStrength);

        // Update the UI to reflect the change
        textViewPrologText.setText("You have chosen Strength. Strength is now " + currentStrength);
    }

    public void healthFunction() {
        // Increment health
        CharacterAttributes attributes = CharacterAttributes.getInstance();
        int currentHealth = attributes.getHealth() + 5;
        attributes.setHealth(currentHealth);

        // Update the UI to reflect the change
        textViewPrologText.setText("You have chosen Health. Health is now " + currentHealth);
    }

    public void dexterityFunction() {
        // Increment dexterity
        CharacterAttributes attributes = CharacterAttributes.getInstance();
        int currentDexterity = attributes.getDexterity() + 3;
        attributes.setDexterity(currentDexterity);

        // Update the UI to reflect the change
        textViewPrologText.setText("You have chosen Dexterity. Dexterity is now " + currentDexterity);
    }

    // Disable other buttons after a choice is made
    public void disableOtherButtons1(Button chosenButton) {
            buttonChoiceStrength.setEnabled(false);
            buttonChoiceHealth.setEnabled(false);
            buttonChoiceDexterity.setEnabled(false);
    }

    public void staminaFunction() {
        CharacterAttributes attributes = CharacterAttributes.getInstance();
        int currentStamina = attributes.getStamina() + 10;
        attributes.setStamina(currentStamina);

        textViewPrologText2.setText("You have chosen Stamina. Stamina is now " + currentStamina);
    }

    public void luckFunction() {
        CharacterAttributes attributes = CharacterAttributes.getInstance();
        int currentLuck = attributes.getLuck() + 1;
        attributes.setLuck(currentLuck);

        textViewPrologText2.setText("You have chosen Luck. Luck is now " + currentLuck);
    }

    public void charismaFunction() {
        CharacterAttributes attributes = CharacterAttributes.getInstance();
        int currentCharisma = attributes.getCharisma() + 2;
        attributes.setCharisma(currentCharisma);

        textViewPrologText2.setText("You have chosen Charisma. Charisma is now " + currentCharisma);
    }

    public void disableOtherButtons2(Button chosenButton) {
            buttonStamina.setEnabled(false);
            buttonLuck.setEnabled(false);
            buttonCharisma.setEnabled(false);
    }

    public void goldFunction() {
        CharacterAttributes attributes = CharacterAttributes.getInstance();
        int currentGold = attributes.getGold() + 20;
        attributes.setGold(currentGold);

        textViewProlog3.setText("You have chosen Gold. Gold is now " + currentGold);
    }

    public void swordFunction() {
        CharacterAttributes attributes = CharacterAttributes.getInstance();
        int currentSword = attributes.getSword() + 1;
        attributes.setSword(currentSword);

        textViewProlog3.setText("You have chosen Sword. You now possess a wooden sword");
    }

    public void healFunction() {
        CharacterAttributes attributes = CharacterAttributes.getInstance();
        int currentHeal = attributes.getHeal() + 3;
        attributes.setHeal(currentHeal);

        textViewProlog3.setText("You have chosen Healing. Number of heals is now " + currentHeal);
    }

    public void disableOtherButtons3(Button chosenButton) {
        buttonGold.setEnabled(false);
        buttonSword.setEnabled(false);
        buttonHeal.setEnabled(false);

        textViewNameText.setVisibility(View.VISIBLE);
        editTextNameInput.setVisibility(View.VISIBLE);
    }

    public void continueFunction() {
        Intent intent = new Intent(getApplicationContext(), Game.class);
        startActivity(intent);
    }
}
